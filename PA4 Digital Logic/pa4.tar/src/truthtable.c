#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int x =1;
int y =0;

int multiplier (int crossmatch, int crop) {
    int h = 1;
    int c = 2;
    for(int i = 0; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 0; i < crop; i++) {
        c = c*crossmatch;
    }
    for(int i = 2; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 3; i < crop; i++) {
        c = c*crossmatch;
    }
    return h;
}
int readers (int bottom, int top) {
    int temp = 1;
    for(int i = 0; i < top; i++) {
        temp = temp*bottom;
    }
    return temp;
}
int loop (int crossmatch, int crop) {
    int h = 1;
    int c = 2;
    for(int i = 0; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 0; i < crop; i++) {
        c = c*crossmatch;
    }
    for(int i = 2; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 3; i < crop; i++) {
        c = c*crossmatch;
    }
    return h;
}
int loop1 (int crossmatch, int crop) {
    int h = 1;
    int c = 2;
    for(int i = 0; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 0; i < crop; i++) {
        c = c*crossmatch;
    }
    for(int i = 2; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 3; i < crop; i++) {
        c = c*crossmatch;
    }
    return h;
}
void LOGICALNOR(int keeperup1, int changes, int std2[], int within, int x, int y) { //not or special operator
    std2[within] = !(std2[keeperup1] || std2[changes]);
}
int loop5 (int crossmatch, int crop) {
    int h = 1;
    int c = 2;
    for(int i = 0; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 0; i < crop; i++) {
        c = c*crossmatch;
    }
    for(int i = 2; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 3; i < crop; i++) {
        c = c*crossmatch;
    }
    return h;
}
int inputSearch(int holder[], int places) {
    int i = places + 1;
    int caps = 2;
    while (i >= caps) {
        holder[i] = !holder[i];
        if (holder[i] == 1) {
            return 1;
        }
    i--;
    }
    return 0;
}
void LOGICALNAND(int keeperup1, int changes, int std1[], int within, int x, int y) { //not and special operator
    std1[within] = !(std1[keeperup1] && std1[changes]);
}

void extracreditsorting(int number[25],int first,int last){ //sorting algorithm for unsorted 
   int i, j, pivot, temp;
   if(first<last){
      pivot=first;
      i=first;
      j=last;

      while(i<j){
         while(number[i]<=number[pivot]&&i<last)
            i++;
         while(number[j]>number[pivot])
            j--;
         if(i<j){
            temp=number[i];
            number[i]=number[j];
            number[j]=temp;
         }
      }
      temp=number[pivot];
      number[pivot]=number[j];
      number[j]=temp;
      extracreditsorting(number,first,j-1);
      extracreditsorting(number,j+1,last);
   }
}



void LOGICALXOR(int keeperup1, int changes, int std3[], int within, int x, int y) { //exclusive or operator bits
    std3[within] = std3[keeperup1] ^ std3[changes];
}
void rightRotatebyOne(int arr[], int n)
{
    int temp = arr[0], i;
    for (i = 0; i < n - 1; i++)
        arr[i] = arr[i + 1];
    arr[n-1] = temp;
}
void LOGICALPASS(int keeperup, int within, int stdfin[], int x, int y) { 
    stdfin[within] = stdfin[keeperup];
}
void rightRotate(int arr[], int d, int n)
{
    int i;
    for (i = 0; i < d; i++)
        rightRotatebyOne(arr, n);
}
void LOGICALNOT(int keeperup, int within, int std3[], int x, int y) { //regular not operator
    std3[within] = !std3[keeperup];
}
void leftRotatebyOne(int arr[], int n)
{
    int temp = arr[0], i;
    for (i = 0; i < n - 1; i++)
        arr[i] = arr[i + 1];
    arr[n-1] = temp;
}
void LOGICALAND(int keeperup1, int changes, int std1[], int within, int x, int y) { //regular and operator
    std1[within] = std1[keeperup1] && std1[changes];
}
void leftRotate(int arr[], int d, int n)
{
    int i;
    for (i = 0; i < d; i++)
        leftRotatebyOne(arr, n);
}
 

 

void LOGICALOR(int keeperup1, int changes, int std2[], int within, int x, int y) { //regular  or operatior
    std2[within] = std2[keeperup1] || std2[changes];
}

void LOGICALsplitter(int *weightinp, int n, int *keeperup, int *within) {
    int s = 0;
    int i;
    for (i = 0; i < readers(2, n); i++) {
        weightinp[within[i]] = 0;
    }
    for (i = 0; i < n; i++) {
        s += weightinp[keeperup[i]] * readers(2, n - i - 1);
    }
    weightinp[within[s]] = 1;
}
void LOGICALpowerer(int *weightinp, int selectorNum, int *keeperup, int *sindex, int within) {
    int s = 0;
    int i;
    for (i = 0; i < selectorNum; i++) {
        s += weightinp[sindex[i]] * readers(2, selectorNum - i - 1);
    }
    weightinp[within] = weightinp[keeperup[s]];
}

void finresarr(int total, char **final) {
    int j = 0;
    while (j < total) {
        printf("%s", final[j]);
        j++;
    }
}

int posofcurr(int total, char **final, char *var) {
    int hp = 0;
    while (hp < total) {
        if (strcmp(final[hp], var) == 0) {
            return hp;
        }
        hp++;
    }
    return -1;
}

struct processes {
    int s;
    int counter;
    int *helpers;
    int *weightinp;
    int *results;
    char logic[100];
};
int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Invalid number of arguments\n");
        return 0;
    }
    FILE *reader = fopen(argv[1], "r");
    if (!reader || argc != 2) {
        printf("NULL\n");
        return 0;
    }
    int loop = 0;
    int i;
    
    int numberss1 = 0;
    int total = 2;
    int readerson = 0;
    int readingoff = 0;
    char wayofcalc[100];
    char **labelshow;
    int *weightinp;
    struct processes* steps = NULL;
    fscanf(reader, " %s", wayofcalc);
    fscanf(reader, "%d", &readerson);
    total += readerson;
    labelshow = calloc(total * sizeof(char *), 1);
    labelshow[0] = "0\0";
    labelshow[1] = "1\0";
    for (i = 0; i < readerson; i++) {
        labelshow[i + 2] = calloc(17 * sizeof(char), 1);
        fscanf(reader, "%16s", labelshow[i + 2]);
    }
    fscanf(reader, " %s", wayofcalc);
    fscanf(reader, "%d", &readingoff); 
    total += readingoff; 
    labelshow = realloc(labelshow, total * sizeof(char *));
    while (loop < readingoff) {
        labelshow[loop + readerson + 2] = calloc(17 * sizeof(char), 1);
        fscanf(reader, "%*[: ]%16s", labelshow[loop + readerson + 2]);
        loop++;
    }
     while (!feof(reader)) {
        int numOutputs = 1;
        int numInputs = 2;
        struct processes step;
        int sc = fscanf(reader, " %s", wayofcalc); 
        if (sc != 1) {
            break;
        }
        numberss1++;
        //get inputs
        step.counter = 0;
        step.s = 0;
        strcpy(step.logic, wayofcalc); //string copy and compare
       
        if (strcmp(wayofcalc, "MULTIPLEXER") == 0) { //string copy and compare
            fscanf(reader, "%d", &numInputs); //string copy and compare
            step.s = numInputs; //string copy and compare
            numInputs = readers(2, numInputs);
        }
        if (strcmp(wayofcalc, "PASS") == 0) { //string copy and compare
            numInputs = 1;
        }
        if (strcmp(wayofcalc, "DECODER") == 0) { //string copy and compare
            fscanf(reader, "%d", &numInputs);
            step.counter = numInputs;
            numOutputs = readers(2, numInputs);
        }
        if (strcmp(wayofcalc, "NOT") == 0) { //string copy and compare
            numInputs = 1; //string copy and compare
        }
        
        step.weightinp = calloc(numInputs * sizeof(int), 1); //calloc for mem alloc
        step.results = calloc(numOutputs * sizeof(int), 1); //calloc for mem alloc
        step.helpers = calloc(step.s * sizeof(int), 1); //calloc for mem alloc
        char v[100];
        for (int j = 0; j < numInputs; j++) {
            fscanf(reader, "%16s", v);
            step.weightinp[j] = posofcurr(total, labelshow, v);
        }
        for (loop = 0; loop < step.s; loop++) {
            fscanf(reader, "%16s", v);
            step.helpers[loop] = posofcurr(total, labelshow, v);
        }
        for (int h = 0; h < numOutputs; h++) {
            fscanf(reader, "%16s", v);
            int placename = posofcurr(total, labelshow, v);
            if (placename == -1) {
                total++;
                labelshow = realloc(labelshow, total * sizeof(char *));
                labelshow[total - 1] = calloc(17 * sizeof(char), 1);
                strcpy(labelshow[total - 1], v);
                step.results[h] = total - 1;
            }
            else {
                step.results[h] = placename;
            }
        }
        if (steps == NULL) {
            steps = calloc(sizeof(struct processes), 1);
        } 
        else {
            steps = realloc(steps, numberss1 * sizeof(struct processes));
        }
        steps[numberss1 - 1] = step;
    }
    weightinp = calloc(total * sizeof(int), 1);
    int j;
    for (j = 0; j < total; j++) {
        if(j==1) {
            weightinp[j] = 1;
        }
        else {
            weightinp[j] = 0;
        }   
    }

    while(1 < 2) {
        int drp = 0;
        for (int hp = 0; hp < readerson; hp++) {
            printf("%d ", weightinp[hp + 2]);
        }
        printf("|");
        for (int dd = 0; dd < numberss1; dd++) {
            struct processes step = steps[dd];
            /*
            if (strcmp(step.logic, "NOT") == 0) {
                LOGICALNOT(step.weightinp[0], step.results[0], weightinp, x, y);
            }
            if (strcmp(step.logic, "AND") == 0) {
                LOGICALAND(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }
            if (strcmp(step.logic, "OR") == 0) {
                LOGICALOR(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }
            if (strcmp(step.logic, "NAND") == 0) {
                LOGICALNAND(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }
            test trial for the extra credit unsort algo
            }*/

            if (strcmp(step.logic, "NOT") == 0) {
                LOGICALNOT(step.weightinp[0], step.results[0], weightinp, x, y);
            }

            if (strcmp(step.logic, "AND") == 0) {
                LOGICALAND(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }

            if (strcmp(step.logic, "OR") == 0) {
                LOGICALOR(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }

            if (strcmp(step.logic, "NAND") == 0) {
                LOGICALNAND(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }

            if (strcmp(step.logic, "NOR") == 0) {
                LOGICALNOR(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }

            if (strcmp(step.logic, "XOR") == 0) {
                LOGICALXOR(step.weightinp[0], step.weightinp[1], weightinp, step.results[0], x, y);
            }

            if (strcmp(step.logic, "PASS") == 0) {
                LOGICALPASS(step.weightinp[0], step.results[0], weightinp, x, y);
            }

            if (strcmp(step.logic, "DECODER") == 0) {
                LOGICALsplitter(weightinp, step.counter, step.weightinp, step.results);
            }

            if (strcmp(step.logic, "MULTIPLEXER") == 0) {
                LOGICALpowerer(weightinp, step.s, step.weightinp, step.helpers, step.results[0]);
            }

        }
        
        while (drp < readingoff) {
            printf(" %d", weightinp[readerson + drp + 2]);
            drp++;
        }

        printf("\n");
        if (!inputSearch(weightinp, readerson)) {
            break;
        }
    }   
    for(int x = 0; x < numberss1; x++) {
        free(steps[x].weightinp);
        free(steps[x].results);
        free(steps[x].helpers);
    }
     for(int x = 2; x < total; x++) {
        free(labelshow[x]);
    }
    free(labelshow);
    free(weightinp);
    free(steps);
    return 0;
} 
int repeatsort (int crossmatch, int crop) {
    int h = 1;
    int c = 2;
    for(int i = 0; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 0; i < crop; i++) {
        c = c*crossmatch;
    }
    for(int i = 2; i < crop; i++) {
        h = c*crossmatch;
    }
    for(int i = 3; i < crop; i++) {
        c = c*crossmatch;
    }
    return h;
}
int topological (int crossmatch, int crop) {
    int i, reversal[10], count=0;
    int j;
    int k;
    int a[10][10];
    int rmmb[10];
int n =0;
for(i=0;i<n;i++){
        rmmb[i]=0;
        reversal[i]=0;
    }
 
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            rmmb[i]=rmmb[i]+a[j][i];
 
    while(count<n){
        for(k=0;k<n;k++){
            if((rmmb[k]==0) && (reversal[k]==0)){
                reversal [k]=1;
            }
            for(i=0;i<n;i++){
                if(a[i][k]==1)
                    rmmb[k]--;
            }
        }
 
        count++;
    }
 
    return 0;
}

